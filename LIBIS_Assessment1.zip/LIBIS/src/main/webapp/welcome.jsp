<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LIBIS - Welcome</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- ===== Top Navigation Bar ===== -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <span class="navbar-brand fw-bold">LIBIS</span>

        <div class="d-flex align-items-center">
            <span class="text-white me-3">
                Hey, <c:out value="${sessionScope.loggedInMember.fullName}" />!
            </span>
            <a href="logout" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<!-- ===== Books Table ===== -->
<div class="container my-4">

    <h4 class="mb-3">Library Catalogue</h4>

    <div class="table-responsive">
        <table class="table table-striped table-hover align-middle bg-white">

            <thead class="table-dark">
            <tr>
                <th scope="col">Title</th>
                <th scope="col">Author</th>
                <th scope="col">Genre</th>
                <th scope="col">Availability</th>
                <th scope="col">Actions</th>
            </tr>
            </thead>

            <tbody>
            <c:forEach var="book" items="${books}">
                <tr>
                    <td><c:out value="${book.title}" /></td>
                    <td><c:out value="${book.author}" /></td>
                    <td><c:out value="${book.genre}" /></td>

                    <td>
                        <c:choose>
                            <c:when test="${book.available}">
                                <span class="badge bg-success">Available</span>
                            </c:when>
                            <c:otherwise>
                                <span class="badge bg-secondary">Borrowed</span>
                            </c:otherwise>
                        </c:choose>
                    </td>

                    <td class="text-nowrap">
                        <a href="#" class="btn btn-sm btn-outline-primary">Search</a>
                        <a href="#" class="btn btn-sm btn-outline-primary">Borrow</a>
                        <a href="#" class="btn btn-sm btn-outline-primary">Reserve</a>
                    </td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>