package com.libis.servlet;

import java.io.IOException;
import java.util.List;

import com.libis.model.Member;
import com.libis.util.LibraryData;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        List<Member> memberList = LibraryData.getMembers();
        Member found = null;

        for (int i = 0; i < memberList.size(); i++) {
            Member m = memberList.get(i);
            if (m.getEmail().equals(email) && m.getPassword().equals(password)) {
                found = m;
                break;
            }
        }

        if (found != null) {
            HttpSession session = request.getSession();
            session.setAttribute("loggedInMember", found);
            // Hand the book list over to the JSP (explained in Step 9)
            session.setAttribute("books", LibraryData.getBooks());
            response.sendRedirect("welcome.jsp");
        } else {
            request.setAttribute("error", "Invalid credentials");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}