package com.libis.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.libis.model.Book;
import com.libis.util.LibraryData;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/catalogue")
public class CatalogueController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String searchTerm = request.getParameter("search");
        List<Book> allBooks = LibraryData.getBooks();
        List<Book> booksToDisplay = new ArrayList<Book>();

        // If there is no search, show all books
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            booksToDisplay = allBooks;
        } else {
            // If there is a search, filter the books by Title
            for (int i = 0; i < allBooks.size(); i++) {
                Book b = allBooks.get(i);
                if (b.getTitle().toLowerCase().contains(searchTerm.toLowerCase())) {
                    booksToDisplay.add(b);
                }
            }
        }

        // Put the list in the request so welcome.jsp can see it
        request.setAttribute("books", booksToDisplay);

        // Forward to the JSP inside WEB-INF
        request.getRequestDispatcher("/WEB-INF/welcome.jsp").forward(request, response);
    }
}