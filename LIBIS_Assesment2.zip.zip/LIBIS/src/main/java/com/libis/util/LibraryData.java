package com.libis.util;

import java.util.ArrayList;
import java.util.List;

import com.libis.model.Book;
import com.libis.model.Member;

public class LibraryData {

    public static List<Member> members = new ArrayList<Member>();
    public static List<Book> books = new ArrayList<Book>();

    static {

        // 5 Members
        members.add(new Member(1, "Amara", "Perera", "amara@libis.com", "pass123"));
        members.add(new Member(2, "Nimal", "Fernando", "nimal@libis.com", "pass123"));
        members.add(new Member(3, "Kavya", "Silva", "kavya@libis.com", "pass123"));
        members.add(new Member(4, "Rohan", "Jayasinghe", "rohan@libis.com", "pass123"));
        members.add(new Member(5, "Dilini", "Wickramasinghe", "dilini@libis.com", "pass123"));

        // 10 Books
        books.add(new Book(1, "Clean Code", "Robert C. Martin", "Programming",
                "A handbook of agile software craftsmanship that teaches how "
                        + "to write readable, maintainable Java code.", true));

        books.add(new Book(2, "The Pragmatic Programmer", "Andrew Hunt", "Programming",
                "Timeless advice on the craft of software development, from "
                        + "tracer bullets to DRY principles.", true));

        books.add(new Book(3, "Introduction to Algorithms", "Thomas H. Cormen",
                "Computer Science",
                "The classic CLRS textbook covering sorting, graphs, dynamic "
                        + "programming and complexity analysis.", false));

        books.add(new Book(4, "Design Patterns", "Erich Gamma",
                "Software Engineering",
                "The Gang of Four catalogue of reusable object-oriented "
                        + "design solutions.", true));

        books.add(new Book(5, "Effective Java", "Joshua Bloch", "Programming",
                "Ninety best-practice items for writing robust and clear "
                        + "Java programs.", false));

        books.add(new Book(6, "The Hobbit", "J.R.R. Tolkien", "Fantasy",
                "Bilbo Baggins is swept into an adventure across Middle-earth "
                        + "to reclaim a dwarven treasure.", true));

        books.add(new Book(7, "1984", "George Orwell", "Dystopian Fiction",
                "A chilling portrayal of a totalitarian state where Big "
                        + "Brother is always watching.", true));

        books.add(new Book(8, "Sapiens", "Yuval Noah Harari", "History",
                "A sweeping history of humankind, from the Stone Age to the "
                        + "present day.", false));

        books.add(new Book(9, "Thinking, Fast and Slow", "Daniel Kahneman",
                "Psychology",
                "An exploration of the two systems that drive the way we "
                        + "think and make decisions.", true));

        books.add(new Book(10, "The Great Gatsby", "F. Scott Fitzgerald",
                "Classic Fiction",
                "Jay Gatsby's pursuit of the American Dream in the Jazz Age "
                        + "of the 1920s.", true));
    }

    public static List<Member> getMembers() {
        return members;
    }

    public static List<Book> getBooks() {
        return books;
    }
}